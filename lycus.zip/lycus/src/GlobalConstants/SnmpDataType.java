package GlobalConstants;

public enum SnmpDataType {
Numeric,Text
}
