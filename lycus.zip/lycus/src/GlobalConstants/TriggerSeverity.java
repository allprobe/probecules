package GlobalConstants;

public enum TriggerSeverity {
	Notice, Warning, High, Disaster, Critical
}
