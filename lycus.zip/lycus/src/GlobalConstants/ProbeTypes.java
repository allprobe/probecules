package GlobalConstants;

public enum ProbeTypes {
	ICMP, PORT, HTTP, SNMP, SNMPv1, RBL, TRACEROUTE, DISCOVERY, BANDWIDTH_ELEMENT, DISK_ELEMENT
}
