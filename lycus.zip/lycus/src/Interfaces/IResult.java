package Interfaces;

public interface IResult {
String getName();
Object getResultObject();
}
