package Interfaces;

public interface IUpdate {
	Boolean Run();
	
	Boolean New();
	Boolean Update();
	Boolean Delete();
}
