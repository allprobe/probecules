package Interfaces;

public interface IJsonUtil {
	
}
