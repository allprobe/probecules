package Interfaces;

public interface IFunction {
public Double[] get();
void add(Double result);
}
