package Model;

public class DiscoveryTrigger {
	public String discovery_trigger_xvalue_unit;
	public Integer discovery_trigger_condition;
	public String discovery_trigger_xvalue;
	public String discovery_trigger_severity;
	public String discovery_trigger_id;
	public Integer discovery_trigger_function;
	public String discovery_trigger_results_vector_type;
}
