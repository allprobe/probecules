package Model;

public class ThreadsUpdates {
	public UpdateModel[] threads_updates;
}
