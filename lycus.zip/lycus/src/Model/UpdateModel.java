package Model;

public class UpdateModel {
	public String update_id;                          
	public String update_type;
	public String probe_id;
	public String user_id;
	public UpdateValueModel update_value;
	public ElementModel[] elements;
	public String template_id;
	public String object_id;
	public String host_id;
}

