package Model;

public class HostParams {
	public String host_id;
	public String name;
	public String hostIp;
	public String snmpTemp;
	public String snmpStatus;
	public String hostStatus;
	public String bucket;
	public String notificationGroups;
}
