package Model;

public class ElementModel {
	public String name;
	public Boolean active;
	public String hostType;
	public Long ifSpeed;
	public Integer index;
	public String hrStorageAllocationUnits;
}
