package Model;

public class TriggerModel {
	public String id;
	public String name;
	public String user_id;
	public Boolean tuple;
	public String status;
	public String severity;
	public String probe_id;
	public ConditionModel[] conditions;
}
