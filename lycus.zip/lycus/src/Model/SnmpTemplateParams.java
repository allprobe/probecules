package Model;

public class SnmpTemplateParams {
public String user_id;
public String snmp_template_id;
public String template_name;
public int version;
public String community;
public String sec;
public String auth_method;
public String username;
public String password;
public String crypt_method;
public String crypt_password;
public int timeout;
public int port;
}
