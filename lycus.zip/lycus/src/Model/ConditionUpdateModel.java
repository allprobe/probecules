package Model;

public class ConditionUpdateModel {
	public String andor;
	public String condition;
	public String function;
	public String index;
	public String xvalue;
	public String results_vector_type;
	public String nvalue;
	public String xvalue_unit;
	public String last_type;
	
}
