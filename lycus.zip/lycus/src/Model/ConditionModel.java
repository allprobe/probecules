package Model;

public class ConditionModel {
	public String function;
	public String andor;
	public String nvalue;
	public String last_type;
	public String index;
	public String xvalue;
	public String xvalue_unit;
	public String results_vector_type;
	public String condition;
}
